const fbScraper = require("fb-post-scraper");
const fs = require("fs");
const Discord = require("discord.js");
const bot = new Discord.Client();
const request = require("request");
const { id, token } = require("./webhook");
const hook = new Discord.WebhookClient(id, token);

bot.commands = new Discord.Collection();

const TOKEN = process.env.TOKEN;

bot.login(TOKEN);

var interval;

const Commands = [
  {
    name: "!kick",
    description: "Kick the user",
    execute(msg, args) {
      if (msg.mentions.users.size) {
        const taggedUser = msg.mentions.users.first();
        msg.channel.send(`You wanted to kick: ${taggedUser.username}`);
      } else {
        msg.reply("Please tag a valid user!");
      }
    },
  },
  {
    name: "!ping",
    description: "Ping!",
    execute(msg, args) {
      //msg.reply("pong");
      //msg.channel.reply("pong");
    },
  },
  {
    name: "!fb-config",
    description: "To configure the bot",
    execute(msg, args) {
      console.log("I am in fb-config");
      initJson();

      if (args[0] === "set-channel") {
        var data = getData();
        data.channel = args[1];
        setData(data);
        console.log("I am in channel");
      }

      if (args[0] === "set-interval") {
        console.log("I am in interval");

        if (isNumeric(args[1])) {
          var data = getData();
          data.interval = Number(args[1]);
          setData(data);
        } else {
          msg.channel.send("Please enter a number for the interval.");
        }
      }

      if (args[0] === "set-page") {
        console.log("I am in page");

        var data = getData();
        data.page = args[1];
        setData(data);
      }
    },
  },
  {
    name: "!fb-start",
    description: "To start the bot",
    execute(msg, args) {
      console.log("I am in fb start");

      var read = getData();

      if (read.channel !== 0 && read.interval !== 0 && read.page !== "") {
        interval = setInterval(function () {
          fbScraper.scrapPosts(read.page);
        }, read.interval * 1000);

        fbScraper.eventEmitter.on("posts", getPosts);
      } else {
        msg.channel.send("Please configure your Bot correctly.");
      }

      console.log(read);
    },
  },
  {
    name: "!fb-stop",
    description: "To stop the bot",
    execute(msg, args) {
      console.log("I am in fb-stop");
      clearInterval(interval);
    },
  },
];

function isNumeric(num) {
  return !isNaN(num);
}

function getPosts(posts) {
  posts.map(function (args, index) {
    //console.log(args.content);

    //console.log(getData().channel.replace(/<|>|#/g, ""));

    const channelId = getData().channel.replace(/<|>|#/g, "");
    //bot.channels.get(channelId).send(args.content);

    //console.log(args.id);
    //console.log(args.link);
    //console.log(args.time);
    //console.log(args.images);

    //const images = args.images.join(" ");
    // bot.channels
    //   .get(channelId)
    //   .send(args.content + " <" + args.link + "> " + "  " + images);
    sendImages(args, channelId);
  });
}

function setData(data) {
  // makes the object a JSON string
  var dataString = JSON.stringify(data);

  //write to  file
  fs.writeFileSync("config.json", dataString);
}

function getData() {
  //read file contents
  var contents = fs.readFileSync("config.json");

  //parse contents
  var data = JSON.parse(contents);

  return data;
}

function initJson() {
  //create file if it's present.
  if (!fs.existsSync("config.json")) {
    console.log("Initialising storage.\n Creating `config.json` file");
    setData({
      channel: 0,
      page: "",
      interval: 0,
    });
  }
}

function sendImages(args, channelId) {
  let embeds = [];

  embeds.push(new Discord.RichEmbed().setDescription(args.content));
  embeds.push(new Discord.RichEmbed().setDescription(args.link));
  args.images.map(function (args, index) {
    embeds.push(
      new Discord.RichEmbed()
        .setTitle("Image " + index)
        .setImage(args)
        .setTimestamp()
        .setFooter("Pulled time:")
    );
  });

  hook.send({ embeds: embeds });
}

function createWebhook(channelId) {
  bot.channels
    .get(channelId)
    .createWebhook("test-webhook", {
      avatar: "https://i.imgur.com/wSTFkRM.png",
    })
    .then((webhook) => console.log(`Created webhook ${webhook}`))
    .catch(console.error);
}

/**
 * 
 *     bot.channels.get(channelId).send({
      embed: {
        description: "image " + index,
        image: { url: args },
      },
    });
 */
// function DownloadImages(imageArray) {
//   imageArray.map(function (args, index) {
//     download(args, "image" + index, function () {
//       console.log("image" + index, " done");
//     });
//   });
// }

// var download = function (uri, filename, callback) {
//   request.head(uri, function (err, res, body) {
//     console.log("content-type:", res.headers["content-type"]);
//     console.log("content-length:", res.headers["content-length"]);

//     request(uri).pipe(fs.createWriteStream(filename)).on("close", callback);
//   });
// };

module.exports = {
  bot,
  Commands,
};
