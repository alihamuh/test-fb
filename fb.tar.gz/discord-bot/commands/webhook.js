const id = "724893563007139902";
const token =
  "BdUngCddcUB1b_aROVW8bDEjah_oPdQEZ1A70Wrs7xzLTUpP_OavNhAOISrjJJ6x9W7v";

module.exports = {
  id,
  token,
};
