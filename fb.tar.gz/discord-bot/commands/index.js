const { bot, Commands } = require("./ping");

module.exports = {
  bot,
  Commands,
};
