const utils = require("fca-unofficial/utils");
const fs = require("fs");
const cheerio = require("cheerio");
var events = require("events");
var eventEmitter = new events.EventEmitter();

const ua =
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36";

function scrapPosts(page) {
  var jar = utils.getJar();
  jar.setCookie(
    utils.formatCookie(["locale", "en_GB", "", "/"], "facebook"),
    "https://www.facebook.com"
  );
  // Open the main page, then we login with the given credentials and finally
  // load the main page again (it'll give us some IDs that we need)
  mainPromise = utils
    .get(page, jar, null, {
      userAgent: ua,
    })
    .then(utils.saveCookies(jar))
    .then((s) => {
      const $ = cheerio.load(s.body);
      let posts = [];
      $(".userContentWrapper").map((i, post) => {
        const elm = $(post);

        // skip pinned posts
        if (elm.find($(`[data-tooltip-content="Pinned Post"]`)).length)
          return {};
        const postData = {};
        const content = getNode($, elm, `div.userContent`);
        if (content) {
          postData.content = content.text();
        }

        const subtitle = getNode($, elm, `div[data-testid="story-subtitle"]`);
        if (subtitle) {
          const link =
            "https://facebook.com" + getNode($, subtitle, `a`).attr("href");
          const time = getNode($, subtitle, "abbr").attr("title");
          const id = subtitle.attr("id");
          postData.id = id;
          postData.link = link;
          postData.time = time;
        }
        postData.images = [];
        const images = getNodes($, elm, `a[rel="theater"]`);
        if (images) {
          images.each((_, node) => {
            const imgSrc = $(node).attr("data-ploi");
            postData.images.push(imgSrc);
          });
        }

        posts.push(postData);
      });
      const newPosts = getNewPosts(posts);
      if (!newPosts || newPosts.length) {
        fs.writeFileSync("posts.json", JSON.stringify(posts));

        eventEmitter.emit("posts", posts);

        // TODO send to discord
      }
    });
}

function getNewPosts(posts) {
  if (!fs.existsSync("posts.json")) return false;
  const prevPosts = JSON.parse(fs.readFileSync("posts.json"));
  const newPosts = posts.filter((p) => prevPosts.every((pp) => pp.id !== p)); //.every(p => posts.some(pp => p.id === pp.id));
  if (newPosts.length) {
    return newPosts;
  }
}

function getNode($, parent, selector) {
  const node = parent.find($(selector));
  if (node.length) {
    return $(node[0]);
  }
}

function getNodes($, parent, selector) {
  const nodes = parent.find($(selector));
  if (nodes.length) {
    return nodes;
  }
}

module.exports = { scrapPosts, eventEmitter };
